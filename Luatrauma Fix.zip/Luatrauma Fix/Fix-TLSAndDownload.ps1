# Fix-TLSAndDownload.ps1
# Enables required services, repairs root certificates, then downloads Luatrauma AutoUpdater.

$ErrorActionPreference = "Stop"

function Assert-Admin {
  $isAdmin = ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent()
  ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

  if (-not $isAdmin) {
    Write-Host "Not running as Administrator. Re-launching elevated..."
    Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
  }
}

function Set-ServiceStartupAndStart {
  param(
    [Parameter(Mandatory=$true)][string]$Name,
    [Parameter(Mandatory=$true)][ValidateSet("Automatic","Manual","Disabled")][string]$StartupType
  )

  Write-Host "Configuring $Name startup: $StartupType"
  Set-Service -Name $Name -StartupType $StartupType -ErrorAction Stop

  $svc = Get-Service -Name $Name -ErrorAction Stop
  if ($svc.Status -ne "Running") {
    Write-Host "Starting $Name"
    Start-Service -Name $Name -ErrorAction Stop
  } else {
    Write-Host "$Name already running"
  }
}

Assert-Admin

Set-ServiceStartupAndStart -Name "wuauserv"  -StartupType Automatic
Set-ServiceStartupAndStart -Name "cryptsvc"  -StartupType Automatic
Set-ServiceStartupAndStart -Name "bits"      -StartupType Automatic
# Windows Installer is not required for TLS/cert repair; some systems block changing its startup type.
try {
  # Start it if possible, but don't fail the script if startup type can't be changed
  $svc = Get-Service -Name "msiserver" -ErrorAction Stop
  if ($svc.Status -ne "Running") { Start-Service -Name "msiserver" -ErrorAction Stop }
} catch {
  Write-Warning "Skipping msiserver: $($_.Exception.Message)"
}

Write-Host "Generating roots.sst from Windows Update..."
& certutil.exe -generateSSTFromWU "$PSScriptRoot\roots.sst" | Out-Host

Write-Host "Adding roots.sst into LocalMachine Root store..."
& certutil.exe -addstore -f root "$PSScriptRoot\roots.sst" | Out-Host

$url  = "https://github.com/Luatrauma/Luatrauma.AutoUpdater/releases/download/latest/Luatrauma.AutoUpdater.win-x64.exe"
$out  = Join-Path $PSScriptRoot "Luatrauma.AutoUpdater.win-x64.exe"

Write-Host "Downloading: $url"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-WebRequest -Uri $url -OutFile $out

Write-Host "Downloaded to: $out"
Write-Host "Launching updater..."
Start-Process $out
Write-Host "Finished."
